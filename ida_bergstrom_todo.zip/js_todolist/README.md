Examination - Todo:

Title: Things I would love to do - A JavaScript to-do-list

By: Ida Bergström

Includes: Bootstrap glyphicons & Google fonts